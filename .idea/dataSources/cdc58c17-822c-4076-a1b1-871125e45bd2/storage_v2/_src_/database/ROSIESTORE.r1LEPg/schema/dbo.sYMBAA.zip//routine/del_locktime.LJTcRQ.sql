
	
create   proc del_locktime
as
begin
	update USERS set locktime = null
		WHERE (SELECT DATEDIFF(MINUTE,locktime,getdate()) 
				from USERS 
				where locktime is not null or locktime != '')>= 15
	delete LOCKUSERS 
		where USERNAME = (SELECT T.USERNAME
					from (SELECT DATEDIFF(MINUTE,TIMELOGFAILS,getdate()) AS Diff,USERNAME,MAX(COUNTS) as C
								from LOCKUSERS 
								where TIMELOGFAILS is not null
								group by USERNAME,TIMELOGFAILS) T
								where T.Diff >=15	)		
	
end
go

