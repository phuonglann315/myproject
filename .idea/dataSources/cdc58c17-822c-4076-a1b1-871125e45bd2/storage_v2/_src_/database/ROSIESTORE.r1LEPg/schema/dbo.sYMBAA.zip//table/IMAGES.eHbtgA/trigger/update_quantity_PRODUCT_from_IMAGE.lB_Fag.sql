create   trigger update_quantity_PRODUCT_from_IMAGE
ON IMAGES
for INSERT, update
AS
begin
	declare @IDPR varchar(10)
	set @IDPR= ( select IDPR from inserted)
	declare @total int
	set @total = (select sum(DETAILQUANTITY) from IMAGES where IDPR=@IDPR)
	update PRODUCT set QUANTITY=@total where IDPR=@IDPR
end
go

