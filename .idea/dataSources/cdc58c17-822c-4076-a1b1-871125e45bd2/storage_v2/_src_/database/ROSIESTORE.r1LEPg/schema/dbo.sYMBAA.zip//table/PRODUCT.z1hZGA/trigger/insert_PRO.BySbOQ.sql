create   trigger insert_PRO
ON PRODUCT
After insert
	as
	begin
		Declare @IDPR int
		Declare @count INT

		Declare @CREATEDATE date
		Set @CREATEDATE=(select CREATEDATE from inserted) 
		if(@CREATEDATE is null or @CREATEDATE= '')
		begin
		set @CREATEDATE=GETDATE()
		end
		else
		begin
		set @CREATEDATE=CONVERT(datetime,@CREATEDATE)
		end
		Set @IDPR=(select IDPR from inserted)
	
		SET  @count= ( select count(IDPR) from PRODUCT)
		IF (@count=0)
			begin
			
			UPDATE PRODUCT set CREATEDATE=@CREATEDATE where (IDPR=@IDPR )
			end
		IF (@count>0)
			begin
			
			UPDATE PRODUCT set CREATEDATE=@CREATEDATE where (IDPR=@IDPR )
			end
	end
go

