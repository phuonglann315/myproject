
create   trigger insert_LOCKUSERS
ON LOCKUSERS 
for INSERT 
AS
begin
	declare @nowtime datetime
	set @nowtime= GETDATE()
	
	declare @USERNAME varchar(25)
	set @USERNAME= ( select USERNAME from inserted)

	declare @temcounts tinyint
	declare @counts tinyint
	set @temcounts = (select max(COUNTS) FROM LOCKUSERS WHERE USERNAME= @USERNAME)
	if (@temcounts is null)
		begin
				update LOCKUSERS set TIMELOGFAILS= @nowtime, COUNTS=1 where USERNAME=@USERNAME
		end
	else
		set @counts=@temcounts +1
		begin
			if(@counts<=5)
				begin
					update LOCKUSERS set TIMELOGFAILS= @nowtime, COUNTS=@counts where( USERNAME=@USERNAME and COUNTS IS NULL)
				end
			if (@counts=5)
				begin
					update USERS set locktime=@nowtime where USERNAME=@USERNAME
					delete LOCKUSERS where USERNAME=@USERNAME
				end
		end
end
go

