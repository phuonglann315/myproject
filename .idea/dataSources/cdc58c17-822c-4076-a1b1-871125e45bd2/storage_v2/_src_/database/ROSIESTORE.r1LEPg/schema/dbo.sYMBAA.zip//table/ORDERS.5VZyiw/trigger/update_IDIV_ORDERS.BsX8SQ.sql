create   trigger update_IDIV_ORDERS
ON ORDERS
for insert
	as
	begin
		declare @nowtime datetime
		set @nowtime= GETDATE()
		Declare @IDIV varchar(10)
		Declare @USERNAME varchar(25)
		Set @IDIV=(select IDIV from inserted) 
		Set @USERNAME=(select USERNAME from inserted)	
			UPDATE ORDERS set CREATETIME=@nowtime where USERNAME=@USERNAME			
	end
go

