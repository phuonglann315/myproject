


create   trigger update_SUBPAID_ORDERS
ON details_ORDERS
for INSERT, update
AS
begin
	declare @IDIV varchar(10)
	set @IDIV= ( select IDIV from inserted)
	declare @total int
	set @total = (select sum(PRICE) from details_ORDERS where IDIV=@IDIV)
	update ORDERS set SUBPAID=@total where IDIV=@IDIV
end
go

