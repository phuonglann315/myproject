create   trigger insert_BRAND
ON BRAND
After insert
	as
	begin
		Declare @IDBR varchar(5)
		Declare @count INT
		Declare @NAMEBR varchar(25)
		Set @IDBR=(select IDENT_CURRENT('BRAND'))
		Set @NAMEBR=(select NAMEBR from inserted)	
		SET  @count= ( select count(IDBR) from BRAND)
		IF (@count=0)
			begin
			Set @IDBR='BR1'
			UPDATE BRAND set IDBR=@IDBR where NAMEBR=@NAMEBR
			end
		IF (@count>0)
			begin
			Set @IDBR=CONCAT('BR',CONVERT(varchar,@count))
			UPDATE BRAND set IDBR=@IDBR where NAMEBR=@NAMEBR
			end
	end
go

