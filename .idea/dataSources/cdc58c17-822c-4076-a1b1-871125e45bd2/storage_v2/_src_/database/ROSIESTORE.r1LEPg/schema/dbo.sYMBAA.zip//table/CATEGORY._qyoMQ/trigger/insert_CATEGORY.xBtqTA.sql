create   trigger insert_CATEGORY
ON CATEGORY
After insert
	as
	begin
		Declare @IDCTGR varchar(5)
		Declare @count INT
		Declare @NAMECTGR varchar(25)
		Set @IDCTGR=(select IDENT_CURRENT('CATEGORY'))
		Set @NAMECTGR=(select NAMECTGR from inserted)	
		SET @count= (select count(IDCTGR) from CATEGORY)
		IF (@count=0)
			begin
			Set @IDCTGR='CT1'
			UPDATE CATEGORY set IDCTGR=@IDCTGR where NAMECTGR=@NAMECTGR
			end
		IF (@count>0)
			begin
			Set @IDCTGR=CONCAT('CT',CONVERT(varchar,@count))
			UPDATE CATEGORY set IDCTGR=@IDCTGR where NAMECTGR=@NAMECTGR
			end
	end
go

